
<h1 align="center">
    IFOOD CLONE 
</h1>

<p align="center">
    Aplicativo criado no curso de React Native da Digital Innovation One, com as coordenadas passadas pelo dev Pablo Henrique.
</p>



## EndPoints

<p>Para consumir dados usamos uma api fake, usando os seguintes endpoints<p>

| NOME         | ENDPOINT                                                                      |
| ------------ | ----------------------------------------------------------------------------- |
| GERAL        | http://my-json-server.typicode.com/pablohdev/app-ifood-clone/db               |
| BANNERS      | http://my-json-server.typicode.com/pablohdev/app-ifood-clone/banner_principal |
| CATEGORIAS   | http://my-json-server.typicode.com/pablohdev/app-ifood-clone/categorias       |
| RESTAURANTES | http://my-json-server.typicode.com/pablohdev/app-ifood-clone/restaurantes     |

<br>
<br>

## Obrigado
